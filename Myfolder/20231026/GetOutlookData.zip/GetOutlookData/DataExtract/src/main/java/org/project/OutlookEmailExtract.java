package org.project;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.mail.*;
import javax.mail.internet.MimeMultipart;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class OutlookEmailExtract {
    private final Set<String> uniqueEmails = new HashSet<>();
    private static final String email_Regex = "<(.*?)>";
    private static final Pattern email_Pattern = Pattern.compile(email_Regex);
    private final String serverHost;
    private final String emailAddress;
    private final String emailPassword;
    private final int port;
    private final String[] headers;
    final Workbook workbook;

    // main method
    public static void main(String[] args) {
        String serverHost = "imap.gmail.com";                   // Outlook IMAP server is "outlook.office365.com"
        String emailAddress = "manish2022job@gmail.com";        //Outlook email address is "s_some@jobtkk.co.jp"
        String emailPassword = "igsv geqg mqwk smpq";           //Outlook email password is "ABC123abc"
        int port = 993;                                         //Outlook IMAP port number

        // Define headers to extract from emails (match the header in Outlook window)
        String[] headers = {
                "No.", "メール送信者", "メール件名", "紹介会社", "名前", "ヨミガナ", "国籍", "応募日", "住まい", "年齢", "日本語能力", "経験", "現年収", "希望年収", "最低希望年収", "コメント",
                "ステータス", "書類審査", "一次面接日", "二次面接日", "内定日", "入社日"
        };
        Workbook workbook = new XSSFWorkbook();
        OutlookEmailExtract outlookEmailExtract = new OutlookEmailExtract(serverHost, emailAddress, emailPassword, port, headers, workbook);
        outlookEmailExtract.processEmailGenerateExcel();
    }

    public OutlookEmailExtract(String serverHost, String emailAddress, String emailPassword, int port, String[] headers, Workbook workbook) {
        this.serverHost = serverHost;
        this.emailAddress = emailAddress;
        this.emailPassword = emailPassword;
        this.port = port;
        this.headers = headers;
        this.workbook = workbook;
    }

    public void processEmailGenerateExcel() {
        Properties properties = configureEmailProperties();
        try (Workbook workbook = createWorkbook()) {
            Session session = getSession(properties);
            Store store = connectToEmailServer(session);
            Folder inbox = openInboxFolder(store);
            Message[] messages = inbox.getMessages();

            validateHeaders();

            Sheet worksheet = createWorksheet(workbook);
            setupSheetStyles(workbook,worksheet);

            int rowNum = 1;
            int number = 1;
            for (Message message : messages) {
                try {
                    String emailSender = extractSenderEmail(message);
                    String emailSubject = extractSubject(message);
                    String emailBody = getEmailBody(message);
                    String senderName = extractReceivedCompanyName(message);

                    // Check if 応募日 is found only in the email body
                    String applicationDate = extractValueFromHeader("応募日", emailBody);
                    String applicationDateFromSubject = extractValueFromHeader("応募日", emailSubject);
                    if (applicationDate != null && applicationDateFromSubject == null) {
                        // Skip processing this email
                        continue;
                    }

                    // check the same email or email body check
                    String uniqueKey = emailSender + "_" + emailBody.hashCode();
                    if (uniqueEmails.contains(uniqueKey)) {
                        continue;
                    } else {
                        uniqueEmails.add(uniqueKey);
                    }
                    // extract values from the body
                    String[] extractedValues = new String[headers.length];
                    for(int i = 0; i <headers.length; i++){
                        extractedValues[i] = extractValueFromHeader(headers[i],emailBody);
                    }
                    if(extractedValues[Arrays.asList(headers).indexOf("応募日")].trim().isEmpty() && hasOtherHeaderValue(extractedValues)){
                        continue;
                    }
                    // check if any headers value is available
                    if(hasOtherHeaderValue(extractedValues)){
                        continue;
                    }
                    Row row = createDataRow(worksheet, rowNum++, number++, emailSender, emailSubject, senderName);
                    populatedDataCell(row, extractedValues);
                    setReceivedDataCell(row, message);

                    message.setFlag(Flags.Flag.SEEN, true);
                } catch (Exception e) {
                    System.out.println("An unexpected error occurred : " + e.getMessage());
                }
            }

            adjustedColumnWidths(worksheet);

            saveExcelFile(workbook);


        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    // create private method for the configure email properties
    private Properties configureEmailProperties() {
        Properties properties = new Properties();
        properties.setProperty("mail.store.protocol", "imaps");
        properties.put("mail.imap.host", serverHost);
        properties.put("mail.imap.ports", String.valueOf(port));

        // return the properties
        return properties;
    }
    // create the workbook
    private Workbook createWorkbook() {
        return new XSSFWorkbook();
    }
    // get session form properties
    private Session getSession(Properties properties) {
        return Session.getInstance(properties, null);
    }
    // connection to email server
    private Store connectToEmailServer(Session session) throws MessagingException {
        Store store = session.getStore();
        store.connect(serverHost, emailAddress, emailPassword);
        return store;
    }

    // method for the open inbox folder
    private Folder openInboxFolder(Store store) throws MessagingException {
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        return folder;
    }

    // check the headers array is null, empty or contains invalid strings
    private void validateHeaders() {
        if (headers == null || headers.length == 0) {
            throw new IllegalArgumentException("The headers array must not be null or empty.");
        }
        for (String header : headers) {
            if (header == null || header.isEmpty()) {
                throw new IllegalArgumentException("The headers array must contain only valid strings.");
            }
        }
    }

    // Method for the worksheet to be created
    private Sheet createWorksheet(Workbook workbook) {
        Sheet existingSheet = workbook.getSheet("Outlook Emails Extracted Data");
        if(existingSheet != null){
            workbook.removeSheetAt(workbook.getSheetIndex(existingSheet));
        }
        return workbook.createSheet("Outlook Emails Extracted Data");
    }

    // style for the worksheet
    private void setupSheetStyles(Workbook workbook, Sheet worksheet) {
    // Code for setting up header cell styles
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

        // Setting font for headerCellStyle
        Font headerFont = workbook.createFont();
        headerFont.setFontName("Meiryo UI");
        headerFont.setFontHeightInPoints((short) 11);
        headerCellStyle.setFont(headerFont);

        // Create a cell style with centered alignment for other cells
        CellStyle cellStyle = workbook.createCellStyle();

        // Setting font for cellStyle
        Font cellFont = workbook.createFont();
        cellFont.setFontName("Meiryo UI");
        cellFont.setFontHeightInPoints((short) 10);
        cellStyle.setFont(cellFont);

        // Create the header cells and the set their styles
        Row headerRow = worksheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerCellStyle);
            worksheet.setDefaultColumnStyle(i,cellStyle);
        }
    }

    // method for the get email sender address,email subject and sender name
    private Row createDataRow(Sheet worksheet, int rowNum, int number, String emailSender, String emailSubject, String senderName) {
        Row row = worksheet.createRow(rowNum);
        row.createCell(0).setCellValue(number);
        row.createCell(1).setCellValue(emailSender);
        row.createCell(2).setCellValue(emailSubject);
        row.createCell(3).setCellValue(senderName);
        return row;
    }
    private void populatedDataCell(Row row, String[] extractedValues) {
        for (int i = 4; i < headers.length; i++) {
            String extractedValue =extractedValues[i];
            Cell cell = row.createCell(i);
            cell.setCellValue(extractedValue);
        }
    }

    // modify the hasOtherHeaderValue method
    private boolean hasOtherHeaderValue(String [] extractedValues){
        for (int i = 1; i <extractedValues.length; i++){
            if(!headers[i].equals("応募日") && !extractedValues[i].trim().isEmpty()){
                return false;
            }
        }
        return true;
    }
    private void setReceivedDataCell(Row row, Message message) throws MessagingException {
        // Code for setting received date cell
        // extracted received date and store in the 応募日 header
        Date receivedDate = message.getReceivedDate();
        if(receivedDate != null){
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            String formattedReceivedDate = dateFormat.format(receivedDate);
            row.createCell(Arrays.asList(headers).indexOf("応募日")).setCellValue(formattedReceivedDate);
        } else {
            row.createCell(Arrays.asList(headers).indexOf("応募日")).setCellValue(" ");
        }
    }

    private void adjustedColumnWidths(Sheet worksheet) {
        // Code for adjusting column widths
        for (int i = 0; i < headers.length; i++) {
            worksheet.autoSizeColumn(i);
            int currentWidth = worksheet.getColumnWidth(i);
            worksheet.setColumnWidth(i,currentWidth + 2 * 256);  // Adding 2 characters' width as extra space
        }
    }

    // 会社名
    private String extractReceivedCompanyName(Message message) throws MessagingException {
        Address[] senders = message.getFrom();
        if (senders != null && senders.length > 0) {
            String senderNameRegex = "^(.*?)\\s*<";
            Pattern senderNamePattern = Pattern.compile(senderNameRegex);
            Matcher matcher = senderNamePattern.matcher(senders[0].toString());
            if (matcher.find()) {
                return senders[0].toString().split("<")[0].trim();
            }
        }
        return "";
    }
    // 送信元
    private String extractSenderEmail(Message message) throws MessagingException {
        Address[] senders = message.getFrom();
        if (senders != null && senders.length > 0) {
            Matcher matcher = email_Pattern.matcher(senders[0].toString());
            if (matcher.find()) {
                return matcher.group(1);
            }
        }
        return "";
    }
    // email subject
    private String extractSubject(Message message) throws MessagingException {
        String emailSubject = message.getSubject();
        if (emailSubject != null){
            String subject_Regex = ".*:\\s*(.+)";
            Pattern subject_Pattern = Pattern.compile(subject_Regex);
            Matcher matcher = subject_Pattern.matcher(emailSubject);
            if (matcher.find()){
                return matcher.group(1).trim();
            }
        }
        return emailSubject;
    }

    // extracted value from email for header array
    private String extractValueFromHeader(String header, String emailBody) {
        if(emailBody == null){
            return "";
        }
        String regex = Pattern.quote(header) + "\\s*[:：|\n\\s]\\s*(.+?)(\\s*\\n|$)";
        Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(emailBody);
        if (matcher.find()) {
            return matcher.group(1).trim();
        } else if ("名前".equals(header)) {
            // Special case for 名前 header : look for either 氏名 or 候補者名 pattern in the email body text
            Pattern namePattern = Pattern.compile("(氏名|名前|候補者名|候補者ID)\\s*[:：|\n\\s]\\s*(.+?)(\\s*\\n|$)");
            Matcher nameMatcher = namePattern.matcher(emailBody);
            if (nameMatcher.find()) {
                return nameMatcher.group(2);
            }
        }
        return "";
    }
    // Email Body
    private String getEmailBody(Message message) throws Exception {
        Object content = message.getContent();
        if (content instanceof String) {
            return (String) content;
        } else if (content instanceof MimeMultipart mimeMultipart) {
            return mimeMultipart.getBodyPart(0).getContent().toString();
        } else {
            return "";
        }
    }
    // workbookをロカルに保存する
    private void saveExcelFile(Workbook workbook){
        String os = System.getProperty("os.name").toLowerCase();
        String filePath;
        if(os.contains("win")){
            // Running on Windows
            filePath = "C:/Users/" + System.getProperty("user.name") + "/Downloads/output.xlsx";
        }else if(os.contains("mac")) {
            // Running on macOS
            filePath = "/Users/" + System.getProperty("user.name") + "/Downloads/output.xlsx";
        } else if (os.contains("linux")){
            // Running on Linux
            filePath = "/home/" + System.getProperty("user.name") + "/Downloads/output.xlsx";
        } else {
            // Default to Windows path if the OS is not recognized
            filePath = "C:/Users/" + System.getProperty("user.name") + "/Downloads/output.xlsx";
        }
        try (FileOutputStream fileOutputStream = new FileOutputStream(filePath)){
            workbook.write(fileOutputStream);
            System.out.println("Excel file has been created successfully at : " + filePath);
        } catch(Exception e){
            System.out.println("Error occurred while saving the Excel file: " + e.getMessage());
        }
    }
}