Outlook Email Reader

This Java application demonstrates how to connect to an Outlook (or any other IMAPS-enabled email service) account using IMAPS and read emails from the inbox. It uses the JavaMail API to interact with the Outlook server securely.
このJavaアプリケーションは、IMAPSを使用してOutlookアカウントに接続し、受信トレイから電子メール読む方法を表示します。JavaMail APIを使用して、Outlookサーバーと安全にやり取りします。

## Prerequisites

- Java Development Kit (JDK) installed on your system.
  Java Development Kit (JDK) がインストールしてるかを確認する。
- Outlook account credentials (email address and password) for the account you want to access.
  アクセスするアカウントのOutlookアカウント資格情報(電子メールアドレスとパスワード)
- IMAPS server details (serverHost, port) specific to your Outlook email service provider.
  Outlook電子メールサービスプロバイダーに固有のIMAPSサーバーの詳細(serverHost,ポート)

## Configuration

Before running the application, you need to configure the Outlook account details in the `config.properties` file. Follow the steps below:

1. Open the resource folder and create`config.properties` file.
   Resourceフォルダを開き、[`config.properties`]ファイルを作成する。
2. Set the `serverHost` to the IMAPS server address provided by your Outlook email service provider (e.g., `imap-mail.outlook.com / outlook.office365.com`).
   `serverHost`をOutlook電子メールサービスプロバイダーから提供されたIMAPSサーバーアドレス`imap-mail.outlook.com / outlook.office365.com`に設定する。
3. Set the `emailAddress` to your Outlook email address (e.g., `yourname@outlook.com`).
   `emailAddress`をOutlook電子メールアドレスに設定する。
4. Set the `emailPassword` to the password of your Outlook account.(e.g., `yourname@outlook.com` password)
   `emailPassword`をOutlook電子メールパスワードに設定する。
5. Set the `port` to the IMAPS port number provided by your Outlook email service provider (e.g., `993` for secure connections).
   「ポート」を、Outlook 電子メール サービス プロバイダーから提供された IMAPS ポート番号に設定します。

**Note:** Make sure to use the correct IMAPS server address and port provided by your Outlook email service provider.
