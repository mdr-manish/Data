package org.example;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.email.*;

import java.io.InputStream;
import java.util.Properties;

public  class Main {
    public static void main(String[] args) {
        Properties properties = new Properties();
        try(InputStream input = Main.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null ){
                System.out.println("config.properties が見つかりません");
                return;
            }
            // load a properties file form class path, inside static method
            properties.load(input);

            // Get property values form the config properties
            String serverHost = properties.getProperty("serverHost");
            String emailAddress = properties.getProperty("emailAddress");
            String emailPassword = properties.getProperty("emailPassword");
            int port = Integer.parseInt(properties.getProperty("port"));

            // Define headers to extracted from emails
            String[] headers = {
                    "No.", "メール送信者", "表題", "紹介会社", "名前", "ヨミガナ", "国籍", "応募日", "住まい", "年齢", "日本語能力", "経験",
                    "現年収", "希望年収", "最低希望年収", "コメント", "ステータス", "書類審査", "一次面接日", "二次面接日", "内定日", "入社日"
            };
            Workbook workbook = new XSSFWorkbook();
            EmailProcess emailProcessor = new EmailProcess(properties,serverHost, emailAddress, emailPassword, port, headers,workbook);
            emailProcessor.processEmailGenerateExcel();

        } catch (Exception e) {
            System.out.println("config.properties の読み取り中にエラーが発生しました。");
        }
    }
}