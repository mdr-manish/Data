package org.example.email;

import org.apache.poi.ss.usermodel.*;

import javax.mail.Message;
import javax.mail.MessagingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExcelUtil {
    static Row createHeaderRow(Sheet worksheet, String[] headers, Workbook workbook) {
        // Setting font for headerCellStyle
        Font headerFont = workbook.createFont();
        headerFont.setFontName("Meiryo UI");
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);


        // Code for setting up header cell styles
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
        headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE1.getIndex());
        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle.setFont(headerFont);
        headerCellStyle.setBorderTop(BorderStyle.THIN);
        headerCellStyle.setBorderBottom(BorderStyle.THIN);
        headerCellStyle.setBorderLeft(BorderStyle.THIN);
        headerCellStyle.setBorderRight(BorderStyle.THIN);

        Row headerRow = worksheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerCellStyle);
        }
        return headerRow;
    }

    static Row createDataRow(Sheet worksheet , int rowNumber, int serialNumber, String emailSender, String emailSubject,
                             String emailSenderName, String[] extractedValues, String[] headers, Message message) throws MessagingException {
        Row row = worksheet.createRow(rowNumber);
        // create a font for all cells
        Font cellFont = worksheet.getWorkbook().createFont();
        cellFont.setFontName("Meiryo UI");
        cellFont.setFontHeightInPoints((short) 10);

        CellStyle cellStyle = createCellStyles(worksheet.getWorkbook(), cellFont);

        // apply cell style to all cells in the row
        for (int i = 0; i < headers.length; i++){
            Cell cell = row.createCell(i);
            // No value(連番)
            if(i == 0){
                cell.setCellValue(serialNumber);
            }
            // 送信元
            else if (i == 1){
                cell.setCellValue(emailSender);
            }
            // 表題
            else if (i == 2){
                cell.setCellValue(emailSubject);
            }
            //紹介会社
            else if (i == 3){
                cell.setCellValue(emailSenderName);
            }
            // 応募日 value is fixed value(実施した日)
            else if ("応募日".equals(headers[i])) {
                String applicationDate = extractedValues[i];
                if (applicationDate.trim().isEmpty()){
                    Date receivedDate = message.getReceivedDate();
                    if (receivedDate != null){
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                        String formattedReceivedDate = dateFormat.format(receivedDate);
                        cell.setCellValue(formattedReceivedDate);
                    }
                }else {
                    cell.setCellValue(applicationDate);
                }
            }
            // ステータス value is fixed value(書類選考)
            else if ("ステータス".equals(headers[i])) {
                cell.setCellValue("書類選考");
            }
            // remaining value which extracted from email body text 
            else {
                String extractedValue = extractedValues[i];
                cell.setCellValue(extractedValue);
            }
            cell.setCellStyle(cellStyle);
        }
        return row;
    }

    static void adjustedColumnWidths(Sheet worksheet, int numHeaders) {
        // Code for adjusting column widths
        for (int i = 0; i < numHeaders; i++) {
            worksheet.autoSizeColumn(i);
            int currentWidth = worksheet.getColumnWidth(i);
            worksheet.setColumnWidth(i,currentWidth );
        }
    }
    
    public static CellStyle createCellStyles(Workbook workbook, Font cellFont) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFont(cellFont);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        return cellStyle;
    }

}
