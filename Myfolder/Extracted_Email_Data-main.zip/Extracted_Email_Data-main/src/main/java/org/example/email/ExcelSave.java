package org.example.email;

import org.apache.poi.ss.usermodel.Workbook;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Logger;

public class ExcelSave {
    private static final Logger LOGGER = Logger.getLogger(ExcelSave.class.getName());

    public void saveExcelFile(Workbook workbook){
        String filePath = getFilePath();
        try(FileOutputStream fileOutputStream = new FileOutputStream(filePath)){
            // save workbook to the specified file path
            workbook.write(fileOutputStream);
            fileOutputStream.close();
            System.out.println("Excel ファイルが正常に作成されました。フファイルパスは " + filePath+ " です。");
        } catch (IOException e) {
            LOGGER.severe("Excel ファイルの保存中にエラーが発生しました。 " + e.getMessage());
        }
    }
    // file path for the saving the Excel file
    private String getFilePath(){
        String os = System.getProperty("os.name").toLowerCase();
        String filePath;
        String separator = File.separator;
        // check the operating system and set the file path
        if (os.contains("win") || os.contains("mac")) {
            filePath = System.getProperty("user.home") + separator + "Downloads" + separator + "OutlookExtractedData.xlsx";
        } else {
            filePath = System.getProperty("user.home") + separator + "Downloads" + separator + "OutputData";
        }
        return filePath;
    }
}
