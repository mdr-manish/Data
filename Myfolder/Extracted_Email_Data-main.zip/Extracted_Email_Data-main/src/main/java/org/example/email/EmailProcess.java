package org.example.email;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.mail.*;
import javax.mail.internet.MimeMultipart;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class EmailProcess {
    private final Set<String> uniqueEmails = new HashSet<>();
    private static final String email_Regex = "<(.*?)>";
    private static final Pattern email_Pattern = Pattern.compile(email_Regex);
    Properties properties;
    private final String serverHost;
    private final String emailAddress;
    private final String emailPassword;
    private final int port;
    private final String [] headers;
    final Workbook workbook;

    public EmailProcess(Properties properties, String serverHost, String emailAddress, String emailPassword, int port, String[] headers, Workbook workbook){
        this.properties = properties;
        this.serverHost = serverHost;
        this.emailAddress = emailAddress;
        this.emailPassword = emailPassword;
        this.port = port;
        this.headers = headers;
        this.workbook = workbook;
    }

    private static final Logger logger = LogManager.getLogger(EmailProcess.class);

    // Processing the email
    public void processEmailGenerateExcel(){
        Properties properties = configureEmailProperties();
        try(Workbook workbook = createWorkbook()){
            Store store = connectToEmailServer(properties);
            Folder inbox = openInboxFolder(store);
            Message [] messages = inbox.getMessages();

            validateHeaders();

            Sheet worksheet = createWorksheet(workbook);


            int rowNumber = 1;
            int serialNumber = 1;
            for (Message message : messages){
                try {
                    String emailSender = extractSenderEmail(message);
                    String emailSubject = extractSubject(message);
                    String emailBody = getEmailBody(message);
                    String emailSenderName = extractCompanyName(message);

                    // Check if 応募日 is found only in the email body
                    String applicationDate = extractValueFromHeader("応募日", emailBody);
                    String applicationDateFromSubject = extractValueFromHeader("応募日", emailSubject);
                    if (applicationDate != null && applicationDateFromSubject == null) {
                        // Skip processing this email
                        continue;
                    }
                    // check the same email sender or email body
                    // 同じメール送信者またはメール本文をチェックする
                    String uniqueKey = emailSender + "_" + emailBody.hashCode();
                    if (uniqueEmails.contains(uniqueKey)) {
                        continue;
                    } else {
                        uniqueEmails.add(uniqueKey);
                    }
                    // extract values from the body
                    String[] extractedValues = new String[headers.length];
                    for(int i = 0; i <headers.length; i++){
                        extractedValues[i] = extractValueFromHeader(headers[i],emailBody);
                    }
                    if(extractedValues[Arrays.asList(headers).indexOf("応募日")].trim().isEmpty() && hasOtherHeaderValue(extractedValues)){
                        continue;
                    }
                     //check if any headers value is available
                    if(hasOtherHeaderValue(extractedValues)){
                        continue;
                    }
                    ExcelUtil.createHeaderRow(worksheet,headers,workbook);
                    ExcelUtil.createDataRow(worksheet, rowNumber++, serialNumber++, emailSender, emailSubject, emailSenderName,extractedValues,headers,message);
                    ExcelUtil.adjustedColumnWidths(worksheet,headers.length);

                    message.setFlag(Flags.Flag.SEEN, true);

                } catch (Exception e) {
                    logger.error("エラーが発生しました。", e);
                }
            }
            // create Excel Save instance
            ExcelSave excelSave = new ExcelSave();
            excelSave.saveExcelFile(workbook);

        } catch (Exception e){
            System.out.println(e.getMessage());
            logger.error("エラーが発生しました。", e);
        }
    }

    // create private method for the configure email properties
    private Properties configureEmailProperties() {
        Properties properties = new Properties();
        properties.setProperty("mail.store.protocol", "imaps");
        properties.put("mail.imaps.host", serverHost);
        properties.put("mail.imaps.ports",String.valueOf(port));
        return properties;
    }

    // get session from the properties
    private Store connectToEmailServer(Properties properties) throws MessagingException{
        Session session = Session.getInstance(properties, null);
        Store store = session.getStore();
        store.connect(serverHost, emailAddress, emailPassword);
        return store;
    }

    // open the inbox folder
    private Folder openInboxFolder(Store store) throws MessagingException{
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        return folder;
    }

    // create the workbook
    private Workbook createWorkbook(){
        return new XSSFWorkbook();
    }

    // check the headers array is null, empty or contains invalid strings
    private void validateHeaders(){
        if(headers == null || headers.length == 0){
            throw new IllegalArgumentException("The headers array must not be null or empty.");
        }
        for (String header : headers) {
            if (header == null || header.trim().isEmpty()) {
                throw new IllegalArgumentException("The headers array must contain only valid strings.");
            }
        }
    }

    // worksheet to be created for the extracted data
    private Sheet createWorksheet (Workbook workbook){
        return workbook.createSheet("Outlookのメールで抽出されたデータ");
    }

    // sender email address
    // 送信元のメールアドレスのみを取得する
    private String extractSenderEmail(Message message) throws MessagingException{
        Address [] senders = message.getFrom();
        if (senders != null) {
            for (Address sender : senders) {
                Matcher matcher = email_Pattern.matcher(sender.toString());
                if (matcher.find()) {
                    return matcher.group(1).trim();
                }
            }
        }
        return "";
    }
    // email subject
    // メールの表題を取得すると:シンボル右側のデーターを取得する
    private String extractSubject(Message message) throws MessagingException {
        String emailSubject = message.getSubject();
        if (emailSubject != null){
            String subject_Regex = ".s*[:：|\n\\s]\\s*(.+)";
            Pattern subject_Pattern = Pattern.compile(subject_Regex);
            Matcher matcher = subject_Pattern.matcher(emailSubject);
            if (matcher.find()){
                return matcher.group(1).trim();
            }
        }
        return emailSubject;
    }

    // Email Body
    // Outlookのメールを文字に変更する
    private String getEmailBody(Message message) throws Exception {
        Object content = message.getContent();
        if (content instanceof String) {
            return (String) content;
        } else if (content instanceof MimeMultipart mimeMultipart) {
            return mimeMultipart.getBodyPart(0).getContent().toString();
        } else {
            return "";
        }
    }


    // Company name extracted form the sender email address
    // 送信元から紹介会社名を取得する
    private String extractCompanyName(Message message) throws MessagingException{
        Address [] senders = message.getFrom();
        if (senders != null ) {

            for (Address sender : senders){
                Matcher matcher = email_Pattern.matcher(sender.toString());
                if (matcher.find()){
                    String emailAddress = matcher.group(1).trim();
                    // user@geekly.com からメールを貰った場合は"Geekly"
                    if (emailAddress.contains("geekly")){
                        return "Geekly";
                    }
                    // user@mynavi.jp からメールを貰った場合は"マイナビ"
                    else if (emailAddress.contains("mynavi")) {
                        return "マイナビ";
                    }
                    // user@rikunabi.com からメールを貰った場合は"リクルート"
                    else if (emailAddress.contains("rikunabi")) {
                        return "リクルート";
                    }
                    // user@levtech.jp からメールを貰った場合は"レバテックダイレクト"
                    else if (emailAddress.contains("levtech")) {
                        return "レバテックダイレクト";
                    }
                    // account@career-bank.net からメールを貰った場合は"キャリアバンク"
                    else if (emailAddress.contains("career-bank")) {
                        return "キャリアバンク";
                    }
                    // Testing data
                    else {
                        String companyName_Regex = "^(.*?)\\s*<";
                        Pattern companyName_Pattern = Pattern.compile(companyName_Regex);
                        Matcher matcher2 = companyName_Pattern.matcher(senders[0].toString());
                        if (matcher2.find()){
                            return senders[0].toString().split("<")[0].trim();
                        }
                    }
                }
            }
        }
        return "";
    }

    // headerにマッチしたグループからデーターを取得する方法
    private String extractValueFromHeader(String header, String emailBody){
        if(emailBody == null ){
            return "";
        }

        switch (header){
            //"氏名:", "名前:", "候補者名:", "候補者ID:"のパターンを探し、その後に続く名前を取得する
            case "名前":
                Pattern namePattern = Pattern.compile("(氏名|名前|候補者名|候補者ID)[：:\\n\\s]\\s*([^(\\n]+)\\s*(?:\\([^)]+\\))?(\\s*\\n|$)");
                Matcher nameMatcher = namePattern.matcher(emailBody);
                if (nameMatcher.find()) {
                    // マッチしたグループから名前を取得する
                    String extractedName = nameMatcher.group(2);
                    // 「様」文字を削除、取得された名前をトリム
                    return extractedName.replace("様", "").trim();
                }
                break;

            //"氏名:", "名前:", "候補者名:", "候補者ID:"のパターンを探し、その後に続く()の中にあるヨミガナを取得する
            case "ヨミガナ":
                Pattern readingNamePattern = Pattern.compile("(氏名|名前|候補者名|候補者ID)[：:\\n\\s]\\s*(.+?)\\s*\\(([^\\)]+)\\)(\\s*\\n|$)");
                Matcher readingNameMatcher = readingNamePattern.matcher(emailBody);
                if (readingNameMatcher.find()) {
                    // マッチしたグループからヨミガナを取得する
                    return readingNameMatcher.group(3).trim();
                }
                break;

            //"住まい:", "現住所:", "住所:":"のパターンを探し、その後に続く住まいを取得する
            case "住まい":
                Pattern addressPattern = Pattern.compile("(住まい|現住所|住所)[\\s　]*[:：][\\s　]*(.+?)(\\s*\\n|$)");
                Matcher addressMatcher = addressPattern.matcher(emailBody);
                if (addressMatcher.find()) {
                    // マッチしたグループから住まいを取得する
                    return addressMatcher.group(2);
                }
                break;

            default:
                String regex = Pattern.quote(header) + "\\s*[:：|\n\\s]\\s*(.+?)(\\s*\\n|$)";
                Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
                Matcher matcher = pattern.matcher(emailBody);
                if (matcher.find()) {
                    return matcher.group(1).trim();
                }
                break;
        }
        return "";
    }
    // modify the hasOtherHeaderValue method
    private boolean hasOtherHeaderValue(String [] extractedValues){
        for (int i = 1; i <extractedValues.length; i++){
            if(!headers[i].equals("応募日") && !extractedValues[i].trim().isEmpty()){
                return false;
            }
        }
        return true;
    }
}